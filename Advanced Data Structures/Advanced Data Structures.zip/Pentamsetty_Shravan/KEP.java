public class KEP {
	int key;
	int element;
	//BTree Pointer;

	public KEP(int key1, int element1) {
		key = key1;
		element = element1;
	}
}
