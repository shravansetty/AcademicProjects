public class Node {
	int balfac;
	Node left;
	Node right;
	int value;
	int element;

	public Node(int key, int element1) {
		value = key;
		element = element1;
	}

	public Node() {
		// Default Constructor if something goes wrong
	}

}
